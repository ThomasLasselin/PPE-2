<?



?>


<!Doctype html>
<html>

    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="Client.css">
    </head>

    <body>
        
        <section>
            <div class="form-box">
                <div class="form-value">
                    <form action="">
                        
                        <h2>Mes voyages</h2>

                        <h2>Mes offres</h2>

                        <a href="Accueil.php"><i class="fa-solid fa-user"></i>Accueil</a>

                    </form>
                </div>
            </div>
        </section>
    
    </body>

</html>