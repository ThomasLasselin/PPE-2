<?
    
    header("Location:Accueil.php")

?>